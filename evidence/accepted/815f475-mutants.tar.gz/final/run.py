from pathlib import Path
import hashlib, json, os, subprocess

base_commit = '815f47518003ac889cf3778b93c095ef879cd9ed'
work = Path('/srv/workers/jobs/modularity-host-test/host-conformance-20260928/workspaces/final-mutants')
art = Path('/srv/worker-state/jobs/modularity-host-test/host-conformance-20260928/artifacts/mutants/final')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip() == base_commit
assert not subprocess.check_output(['git','status','--porcelain'],cwd=work).strip()
mutations = [
  ('early-import', 'src/admission/run.ts', lambda s: "import '../fixtures/candidates/a.mjs';\n" + s,
   'wrong-target refuses', 'tests/admission/subprocess.test.mjs', 'a:evaluate'),
  ('swapped-loader', 'src/admission/run.ts', lambda s: s.replace(
   "{ implementationId: 'test/provider/a', load: () => import('../fixtures/candidates/a.mjs') }",
   "{ implementationId: 'test/provider/a', load: () => import('../fixtures/candidates/b.mjs') }", 1),
   'positive A imports', 'tests/admission/subprocess.test.mjs', 'b:write'),
  ('missing-effect-fence', 'src/host/lifetime.ts', lambda s: s.replace(
   '  effect(value: string): void {\n    this.assertReady(this.generation);\n    this.effects.push(value);',
   '  effect(value: string): void {\n    // deliberate mutation: no authority fence\n    this.effects.push(value);', 1),
   'post-await commit is fenced', 'tests/lifecycle/lifecycle.test.mjs', 'Missing expected rejection.'),
  ('untracked-construction', 'src/host/lifetime.ts', lambda s: s.replace(
   'const tickets = [...(this.construction ? [this.construction] : []), ...this.operations];',
   'const tickets = [...this.operations];', 1),
   'reserved acquisition delivered after seal', 'tests/lifecycle/lifecycle.test.mjs', '0 !== 1'),
]
records=[]
env=os.environ.copy(); env.update({'HOME':str(work),'TMPDIR':'/tmp','LANG':'C'})
for name,path,mutate,pattern,testfile,signal in mutations:
    source=work/path
    original=source.read_text()
    changed=mutate(original)
    assert changed != original, name
    try:
        source.write_text(changed)
        patch=subprocess.check_output(['git','diff','--binary','--',path],cwd=work)
        assert patch
        (art/(name+'.patch')).write_bytes(patch)
        run=subprocess.run(['node','--test','--test-name-pattern',pattern,testfile],cwd=work,env=env,
                           capture_output=True,text=True,timeout=45)
        log=run.stdout+'\nSTDERR:\n'+run.stderr
        (art/(name+'.log')).write_text(log)
        records.append({'id':name,'baseCommit':base_commit,'patchSha256':hashlib.sha256(patch).hexdigest(),
                        'logSha256':hashlib.sha256(log.encode()).hexdigest(),'exitCode':run.returncode,
                        'expectedSignal':signal,'signalObserved':signal in log})
    finally:
        source.write_text(original)
assert all(r['exitCode']!=0 and r['signalObserved'] for r in records),records
assert not subprocess.check_output(['git','status','--porcelain'],cwd=work).strip()
summary={'subject':'published-0.1-final-head-mutants','baseCommit':base_commit,'node':subprocess.check_output(['node','--version'],text=True).strip(),
         'lockSha256':hashlib.sha256((work/'pnpm-lock.yaml').read_bytes()).hexdigest(),
         'restoredClean':True,'mutants':records}
(art/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
